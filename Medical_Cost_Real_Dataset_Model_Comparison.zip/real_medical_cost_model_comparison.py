"""
Improved Mini Project:
Medical Insurance Cost Prediction Using a Basic Neural Network vs Analytical Linear Regression

Dataset: Medical Cost Personal Dataset (1,338 US health insurance beneficiaries,
documented in Brett Lantz, Machine Learning with R, public domain).
Important: This is historical US beneficiary billing data expressed in USD ($),
not current Indian health insurance policy quotes or clinical hospital tariffs.
"""

import os
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

try:
    from sklearn.model_selection import train_test_split
    from sklearn.pipeline import Pipeline
    from sklearn.preprocessing import StandardScaler
    from sklearn.neural_network import MLPRegressor
    from sklearn.linear_model import LinearRegression
    from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
    SKLEARN_AVAILABLE = True
except ImportError:
    SKLEARN_AVAILABLE = False


# ==============================================================================
# Built-in Analytical & Neural Network Implementations (Pure NumPy Fallback)
# Ensures the script runs identically even in environments without scikit-learn.
# ==============================================================================

def _train_test_split_np(X_df, y_ser, test_size=0.20, random_state=42):
    rng = np.random.default_rng(random_state)
    n = len(X_df)
    indices = rng.permutation(n)
    n_test = int(round(n * test_size))
    test_idx = indices[:n_test]
    train_idx = indices[n_test:]
    return (
        X_df.iloc[train_idx].copy(),
        X_df.iloc[test_idx].copy(),
        y_ser.iloc[train_idx].copy(),
        y_ser.iloc[test_idx].copy(),
    )


class AnalyticalLinearRegressionModel:
    """
    Analytical ML Model: Ordinary Least Squares (OLS) Linear Regression
    solved directly via the closed-form Normal Equation:
        theta = (X_aug^T * X_aug)^+ * X_aug^T * y
    Includes built-in z-score feature standardization (StandardScaler).
    """

    def __init__(self):
        self.mean_ = None
        self.scale_ = None
        self.theta_ = None

    def fit(self, X, y):
        X_arr = np.asarray(X, dtype=np.float64)
        y_arr = np.asarray(y, dtype=np.float64)
        self.mean_ = X_arr.mean(axis=0)
        self.scale_ = X_arr.std(axis=0)
        self.scale_[self.scale_ == 0] = 1.0
        X_scaled = (X_arr - self.mean_) / self.scale_

        # Augment with bias column of 1s and solve Normal Equation analytically
        X_aug = np.column_stack([np.ones(len(X_scaled)), X_scaled])
        self.theta_ = np.linalg.pinv(X_aug.T @ X_aug) @ (X_aug.T @ y_arr)
        return self

    def predict(self, X):
        X_arr = np.asarray(X, dtype=np.float64)
        X_scaled = (X_arr - self.mean_) / self.scale_
        X_aug = np.column_stack([np.ones(len(X_scaled)), X_scaled])
        return X_aug @ self.theta_


class BasicMLPRegressorModel:
    """
    Basic Neural Network: Multi-Layer Perceptron (MLP) Regressor
    Architecture: Input -> Dense(64, ReLU) -> Dense(32, ReLU) -> Dense(1, Linear)
    Trained with mini-batch Adam optimizer, L2 weight decay, and early stopping.
    Includes built-in z-score standardization for inputs and target.
    """

    def __init__(
        self,
        hidden_layer_sizes=(64, 32),
        lr=0.015,
        l2_alpha=1e-3,
        max_iter=350,
        validation_fraction=0.1,
        n_iter_no_change=20,
        batch_size=64,
        random_state=42,
    ):
        self.hidden_layer_sizes = hidden_layer_sizes
        self.lr = lr
        self.l2_alpha = l2_alpha
        self.max_iter = max_iter
        self.validation_fraction = validation_fraction
        self.n_iter_no_change = n_iter_no_change
        self.batch_size = batch_size
        self.random_state = random_state

    @staticmethod
    def _relu(z):
        return np.maximum(0.0, z)

    def fit(self, X, y):
        rng = np.random.default_rng(self.random_state)
        X_arr = np.asarray(X, dtype=np.float64)
        y_arr = np.asarray(y, dtype=np.float64).reshape(-1, 1)

        # Standardize features and target for stable neural network optimization
        self.x_mean_ = X_arr.mean(axis=0)
        self.x_scale_ = X_arr.std(axis=0)
        self.x_scale_[self.x_scale_ == 0] = 1.0
        X_scaled = (X_arr - self.x_mean_) / self.x_scale_

        self.y_mean_ = y_arr.mean()
        self.y_scale_ = y_arr.std()
        if self.y_scale_ == 0:
            self.y_scale_ = 1.0
        y_scaled = (y_arr - self.y_mean_) / self.y_scale_

        # Validation split for early stopping
        n = len(X_scaled)
        n_val = max(1, int(round(n * self.validation_fraction)))
        perm = rng.permutation(n)
        val_idx, tr_idx = perm[:n_val], perm[n_val:]
        X_tr, y_tr = X_scaled[tr_idx], y_scaled[tr_idx]
        X_val, y_val = X_scaled[val_idx], y_scaled[val_idx]

        # He initialization for layers: Input -> h1 -> h2 -> 1
        d_in = X_scaled.shape[1]
        h1, h2 = self.hidden_layer_sizes
        W1 = rng.normal(0.0, np.sqrt(2.0 / d_in), size=(d_in, h1))
        b1 = np.zeros((1, h1))
        W2 = rng.normal(0.0, np.sqrt(2.0 / h1), size=(h1, h2))
        b2 = np.zeros((1, h2))
        W3 = rng.normal(0.0, np.sqrt(2.0 / h2), size=(h2, 1))
        b3 = np.zeros((1, 1))

        params = [W1, b1, W2, b2, W3, b3]
        m = [np.zeros_like(p) for p in params]
        v = [np.zeros_like(p) for p in params]
        beta1, beta2, eps = 0.9, 0.999, 1e-8
        step = 0

        best_val_loss = np.inf
        best_params = [p.copy() for p in params]
        no_improve = 0

        for epoch in range(self.max_iter):
            batch_perm = rng.permutation(len(X_tr))
            for start in range(0, len(X_tr), self.batch_size):
                idx = batch_perm[start : start + self.batch_size]
                xb, yb = X_tr[idx], y_tr[idx]
                bs = len(xb)

                # Forward pass
                z1 = xb @ params[0] + params[1]
                a1 = self._relu(z1)
                z2 = a1 @ params[2] + params[3]
                a2 = self._relu(z2)
                out = a2 @ params[4] + params[5]

                # Backpropagation (MSE loss + L2 regularization)
                dout = (2.0 / bs) * (out - yb)
                dW3 = a2.T @ dout + self.l2_alpha * params[4]
                db3 = dout.sum(axis=0, keepdims=True)

                da2 = dout @ params[4].T
                dz2 = da2 * (z2 > 0)
                dW2 = a1.T @ dz2 + self.l2_alpha * params[2]
                db2 = dz2.sum(axis=0, keepdims=True)

                da1 = dz2 @ params[2].T
                dz1 = da1 * (z1 > 0)
                dW1 = xb.T @ dz1 + self.l2_alpha * params[0]
                db1 = dz1.sum(axis=0, keepdims=True)

                grads = [dW1, db1, dW2, db2, dW3, db3]
                step += 1
                for i in range(len(params)):
                    m[i] = beta1 * m[i] + (1.0 - beta1) * grads[i]
                    v[i] = beta2 * v[i] + (1.0 - beta2) * (grads[i] ** 2)
                    m_hat = m[i] / (1.0 - beta1 ** step)
                    v_hat = v[i] / (1.0 - beta2 ** step)
                    params[i] -= self.lr * m_hat / (np.sqrt(v_hat) + eps)

            # Evaluate validation loss for early stopping
            val_a1 = self._relu(X_val @ params[0] + params[1])
            val_a2 = self._relu(val_a1 @ params[2] + params[3])
            val_pred = val_a2 @ params[4] + params[5]
            val_loss = float(np.mean((val_pred - y_val) ** 2))

            if val_loss < best_val_loss - 1e-5:
                best_val_loss = val_loss
                best_params = [p.copy() for p in params]
                no_improve = 0
            else:
                no_improve += 1
                if no_improve >= self.n_iter_no_change:
                    break

        self.params_ = best_params
        return self

    def predict(self, X):
        X_arr = np.asarray(X, dtype=np.float64)
        X_scaled = (X_arr - self.x_mean_) / self.x_scale_
        W1, b1, W2, b2, W3, b3 = self.params_
        a1 = self._relu(X_scaled @ W1 + b1)
        a2 = self._relu(a1 @ W2 + b2)
        out_scaled = (a2 @ W3 + b3).ravel()
        return out_scaled * self.y_scale_ + self.y_mean_


def compute_mae(y_true, y_pred):
    return float(np.mean(np.abs(np.asarray(y_true) - np.asarray(y_pred))))


def compute_rmse(y_true, y_pred):
    return float(np.sqrt(np.mean((np.asarray(y_true) - np.asarray(y_pred)) ** 2)))


def compute_r2(y_true, y_pred):
    y_t = np.asarray(y_true, dtype=np.float64)
    y_p = np.asarray(y_pred, dtype=np.float64)
    ss_res = np.sum((y_t - y_p) ** 2)
    ss_tot = np.sum((y_t - np.mean(y_t)) ** 2)
    return float(1.0 - (ss_res / ss_tot))


# ==============================================================================
# Main Project Pipeline
# ==============================================================================

# 1. Load a real, documented dataset.
print("Loading the Medical Cost Personal Dataset...")
script_dir = os.path.dirname(os.path.abspath(__file__))
csv_path = os.path.join(script_dir, "medical_insurance_dataset.csv")
raw_data = pd.read_csv(csv_path)

print("\nFirst five rows:")
print(raw_data.head().to_string(index=False))
print(f"\nDataset rows: {len(raw_data)}")
print("Raw attributes: age, sex, bmi, children, smoker, region")
print("Target: charges (annual individual medical costs billed in USD)")
print("Dataset source: Medical Cost Personal Dataset (Brett Lantz, Machine Learning with R).")

# Encode categorical variables (sex, smoker, region) into numeric features
data = pd.get_dummies(raw_data, columns=["sex", "smoker", "region"], drop_first=True, dtype=float)
feature_names = [col for col in data.columns if col != "charges"]

# 2. Separate features and target.
X = data[feature_names]
y = data["charges"]

# 3. Split into training and testing sets.
if SKLEARN_AVAILABLE:
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.20, random_state=42
    )
else:
    X_train, X_test, y_train, y_test = _train_test_split_np(
        X, y, test_size=0.20, random_state=42
    )

# 4. Build two models: Analytical Linear Regression vs Basic Neural Network (MLP).
if SKLEARN_AVAILABLE:
    linear_model = Pipeline([
        ("scaler", StandardScaler()),
        ("model", LinearRegression())
    ])
    neural_network = Pipeline([
        ("scaler", StandardScaler()),
        ("model", MLPRegressor(
            hidden_layer_sizes=(64, 32),
            activation="relu",
            solver="adam",
            max_iter=500,
            learning_rate_init=0.01,
            early_stopping=True,
            validation_fraction=0.1,
            n_iter_no_change=20,
            random_state=42
        ))
    ])
else:
    linear_model = AnalyticalLinearRegressionModel()
    neural_network = BasicMLPRegressorModel(
        hidden_layer_sizes=(64, 32),
        lr=0.015,
        max_iter=350,
        validation_fraction=0.1,
        n_iter_no_change=20,
        random_state=42
    )

# 5. Train both models on the same training data.
print("\nTraining Analytical Model (Linear Regression - Normal Equation)...")
linear_model.fit(X_train, y_train)

print("Training Basic Neural Network (MLP 64x32 ReLU)...")
neural_network.fit(X_train, y_train)

# 6. Evaluate both models on the same unseen test data.
models = {
    "Linear Regression (Analytical OLS)": linear_model,
    "Neural Network (MLP 64x32)": neural_network
}
rows = []
predictions = {}

for name, model in models.items():
    pred = model.predict(X_test)
    predictions[name] = pred
    rows.append({
        "Model": name,
        "MAE (USD)": compute_mae(y_test, pred),
        "RMSE (USD)": compute_rmse(y_test, pred),
        "R2": compute_r2(y_test, pred)
    })

comparison = pd.DataFrame(rows)
print("\nMODEL COMPARISON")
print(comparison.to_string(index=False, float_format=lambda value: f"{value:.4f}"))
comparison.to_csv(os.path.join(script_dir, "model_comparison.csv"), index=False)

# 7. Save actual and predicted values for further inspection.
prediction_table = pd.DataFrame({
    "Actual_Charges_USD": y_test.to_numpy(),
    "Linear_Regression_Prediction": predictions["Linear Regression (Analytical OLS)"],
    "Neural_Network_Prediction": predictions["Neural Network (MLP 64x32)"]
})
prediction_table.to_csv(os.path.join(script_dir, "real_dataset_predictions.csv"), index=False)

# 8. Plot actual vs predicted for each model.
fig, axes = plt.subplots(1, 2, figsize=(12, 5))
colors = ["#2b6cb0", "#2f855a"]
for ax, (name, _), color in zip(axes, models.items(), colors):
    pred = predictions[name]
    ax.scatter(y_test, pred, alpha=0.35, color=color, edgecolors="none", s=28)
    lower = min(y_test.min(), pred.min())
    upper = max(y_test.max(), pred.max())
    ax.plot([lower, upper], [lower, upper], linestyle="--", color="#c53030", linewidth=1.5, label="Ideal Fit (y = x)")
    ax.set_xlabel("Actual medical charges (USD)")
    ax.set_ylabel("Predicted medical charges (USD)")
    ax.set_title(name)
    ax.grid(True, linestyle=":", alpha=0.5)
    ax.legend(loc="upper left", frameon=True)
plt.tight_layout()
plt.savefig(os.path.join(script_dir, "model_comparison_plot.png"), dpi=150)
plt.close(fig)

print("\nSaved files:")
print("- model_comparison.csv")
print("- real_dataset_predictions.csv")
print("- model_comparison_plot.png")
print("\nInterpretation:")
print("- Lower MAE and RMSE generally mean smaller prediction errors.")
print("- Higher R2 generally means a better fit on this unseen test split.")
print("- The Neural Network captures non-linear feature interactions (such as")
print("  high BMI combined with smoking status) that a purely additive linear")
print("  regression model cannot represent without manual interaction terms.")
print("\nLimitation: Historical US health insurance charges (in USD) are not suitable")
print("for estimating current hospital bills or insurance premiums in India.")
