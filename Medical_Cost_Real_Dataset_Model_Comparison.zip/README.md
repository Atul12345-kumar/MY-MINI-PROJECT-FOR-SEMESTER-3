# Improved Mini Project: Medical Insurance Cost Prediction

## What changed from the beginner version?
- Uses a real, documented dataset (`medical_insurance_dataset.csv`, 1,338 rows) rather than synthetic example data.
- Includes demographic, clinical, and geographic location features (`age`, `sex`, `bmi`, `children`, `smoker`, and `region`).
- Compares an **Analytical ML Model** (Ordinary Least Squares Linear Regression via the closed-form Normal Equation) with a **Basic Neural Network** (`MLPRegressor` with two hidden layers of 64 and 32 ReLU units).
- Reports **MAE**, **RMSE**, and **R-squared ($R^2$)** on the same unseen 20% test split (`268` records).
- Saves a summary metrics CSV, full test-set predictions CSV, and a side-by-side comparison plot.
- Includes a self-contained NumPy fallback for both the analytical Normal Equation solver and the `(64, 32)` ReLU neural network so the script runs even in environments where `scikit-learn` is not yet installed.

## Dataset warning
This project uses the public-domain **Medical Cost Personal Dataset** (1,338 US health insurance beneficiaries, documented in Brett Lantz's *Machine Learning with R*). The target variable `charges` is annual individual medical cost billed in **USD ($)**. It is not a dataset of current Indian health insurance policies or hospital tariffs and should not be used to estimate real clinical or insurance costs in India.

## Requirements
Python 3.10+ recommended and VS Code.

## Run
1. Extract the ZIP and open the folder in VS Code.
2. Open a terminal in the project folder.
3. Install dependencies:
   `python -m pip install -r requirements.txt`
4. Run the comparison script:
   `python real_medical_cost_model_comparison.py`

Because `medical_insurance_dataset.csv` is bundled directly in the project folder, no internet connection is required to run the script.

## Output files
- `model_comparison.csv`: evaluation metrics (MAE, RMSE, and $R^2$) for both models.
- `real_dataset_predictions.csv`: actual and predicted test-set medical charges (USD) for all 268 unseen test samples.
- `model_comparison_plot.png`: two side-by-side actual-versus-predicted scatter plots with ideal $y = x$ reference lines.

## Benchmark results on the 20% test split
| Model | MAE (USD) | RMSE (USD) | $R^2$ |
| :--- | ---: | ---: | ---: |
| **Linear Regression (Analytical OLS)** | 3,954.5170 | 5,526.3338 | 0.7556 |
| **Neural Network (MLP 64x32)** | 3,428.4895 | 4,631.6875 | 0.8283 |

## Key concepts
- **Features:** Beneficiary characteristics including `age` (years), `sex` (male/female), `bmi` (body mass index in $\text{kg/m}^2$), `children` (number of covered dependents), `smoker` (yes/no), and residential `region` (northeast, northwest, southeast, southwest).
- **Target:** Annual individual medical costs billed by health insurance (`charges` in USD).
- **Linear Regression (Analytical OLS):** A closed-form analytical baseline ($\hat{\theta} = (X^T X)^{-1} X^T y$) that models target charges as a weighted linear combination of the standardized input features.
- **MLPRegressor (Basic Neural Network):** A multi-layer perceptron regression network (`64 -> 32` hidden ReLU neurons trained with Adam and early stopping) capable of learning non-linear feature interactions—such as the sharp cost jump when both smoking status and elevated BMI are present.
- **MAE:** Mean Absolute Error; average absolute dollar difference between actual and predicted charges.
- **RMSE:** Root Mean Squared Error; penalizes large outlier errors more heavily than MAE.
- **$R^2$ (Coefficient of Determination):** Proportion of variance in unseen test charges explained by the model (higher is better on the same test set).

## Next improvement for an India-focused project
Source a verified Indian healthcare or insurance dataset (for example, IRDAI or public hospital claim records) with clear documentation, city/tier classification (Metro vs. Tier-2/Tier-3), sum-insured tiers, pre-existing condition indicators, and amounts denominated in Indian Rupees (INR). Clean missing values, perform an 80/20 train-test split, and compare analytical regression baselines against neural networks.
